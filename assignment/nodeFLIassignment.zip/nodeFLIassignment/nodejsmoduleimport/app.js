const si = require('./utils.js');

console.log("Simple interest is: " + si.simpleInterest(1000,10,5));