const simpleInterest = function(p,r,t){
	return (p*r*t)/100;
}

module.exports = {
	simpleInterest
};